package com.emp.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.emp.bean.Employee;
import com.emp.dao.EmpDAO;
import com.emp.exceptions.AccountException;

public class EmpServiceTest {

	Employee e;
	EmpDAO se;
	
	@Test
	public void testCreateAccount() throws AccountException {
		e=new Employee();
		se=new EmpDAO();
		//e.setAcunt_num("9876543210");
		e.setPh_num("9236547890");
		e.setPin("1224");
		e.setBalance(10000);
		e.setaadhar("987654322212");
		e.setpan("QWASD1234Q");
		e.setEname("sandy16");
		e.setHist("Account opened");
		assertTrue(se.createAccount(e));
	
	}

	@Test
	public void testShowBalance() throws AccountException {
		se=new EmpDAO();

		assertNotSame(0, se.showBalance("9236547890"));
		}

	@Test
	public void testDeposite() throws AccountException {
		se=new EmpDAO();

		assertTrue(se.deposite(5000, "9236547890"));


		}

	@Test
	public void testWithdraw() throws AccountException {
		se=new EmpDAO();
		assertTrue(se.withdraw(5000, "9236547890"));
		}

	@Test
	public void testPrintTransaction() throws AccountException {
		se=new EmpDAO();
		String s="Account opened\nAmount of 5000.0 is deposited into the account";
		assertNotSame(s,se.printTransaction("9236547890"));

		}

}
