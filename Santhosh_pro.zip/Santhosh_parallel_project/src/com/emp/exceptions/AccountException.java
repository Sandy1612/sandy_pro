package com.emp.exceptions;

@SuppressWarnings("serial")
public class AccountException extends Exception {
	
	private String msg;

	public AccountException(){
		
	}

	public AccountException(String msg){
		this.msg=msg;
	}
	
	public AccountException(Exception e){
		
		System.out.println(e);
		
	}

	@Override
	public String toString() {
		return "AccountException [msg=" + msg + "]";
	}
	
}
