package com.emp.service;

import com.emp.bean.Employee;
import com.emp.exceptions.AccountException;

public interface IEmpService {
	
	public boolean createAccount(Employee e) throws AccountException;
	public double showBalance(String acunt_num) throws AccountException;
	public boolean deposite(double temp, String acunt_num) throws AccountException;
	public boolean withdraw(double temp, String acunt_num) throws AccountException;
	public String printTransaction(String acunt_num) throws AccountException;
	
	
}
