package com.emp.dao;

import com.emp.bean.Employee;
import com.emp.exceptions.AccountException;


public interface IEmpDAO {
	
	public boolean createAccount(Employee e) throws AccountException;
	public double showBalance(String acunt_num) throws AccountException;
	public boolean deposite(double temp, String acunt_num) throws AccountException;
	public boolean withdraw(double temp, String acunt_num) throws AccountException;
	public String printTransaction(String acunt_num) throws AccountException;
	//public void fundTransfer();
	

}
