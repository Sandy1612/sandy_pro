package com.emp.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;

import com.emp.bean.Employee;
import com.emp.exceptions.AccountException;
import com.emp.util.JPAUtil;



public class EmpDAO implements IEmpDAO {
	private EntityManager entityManager=null;
	Employee e = new Employee();
	
	
	public boolean createAccount(Employee e) throws AccountException
	{		EntityManager entityManager=null;
		try{
		
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();//above lines substitution
			e.setAcunt_num(e.getPh_num());
			entityManager.persist(e);
			entityManager.getTransaction().commit();			
		}catch(PersistenceException ex) {
			throw new AccountException(ex);
		}finally {
			entityManager.close();
		}
	
		return true; 
	   
	    
	}

	
	public double showBalance(String acunt_num) throws AccountException
	{
		try{ 
			entityManager=JPAUtil.getEntityManager();
			
			e=entityManager.find(Employee.class, acunt_num);

			return e.getBalance();
							
						
		}catch(PersistenceException ex) {
			throw new AccountException(ex);
		}
		
	}

	
	public boolean deposite(double temp,String acunt_num) throws AccountException
	{
		try{ 
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			e=entityManager.find(Employee.class, acunt_num);
			double s=temp+e.getBalance();
			e.setBalance(s);
			e.setHist(e.getHist()+"\nAmount of "+temp+" is deposited into the account");
			entityManager.merge(e);
			
			entityManager.getTransaction().commit();	
			return true;
		}catch(PersistenceException ex) {
			throw new AccountException(ex);
		}finally {
			entityManager.close();
		}
		
			
		
	}

	
	public boolean withdraw(double temp,String acunt_num) throws AccountException
	{
		try{ 
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			e=entityManager.find(Employee.class, acunt_num);
			double s=e.getBalance()-temp;
			e.setBalance(s);
			e.setHist(e.getHist()+"\nAmount of "+temp+" is withdrawn from the account");
			entityManager.merge(e);
			
			entityManager.getTransaction().commit();	
			return true;
		}catch(PersistenceException ex) {
			throw new AccountException(ex);
		}finally {
			entityManager.close();
		}
		
	}

	
	public String printTransaction(String acunt_num) throws AccountException
	{//EntityManager entityManager=null;
		try{ //EntityManager entityManager=null;
			entityManager=JPAUtil.getEntityManager();
			e=entityManager.find(Employee.class, acunt_num);
			
			return e.getHist();
		
	}catch(PersistenceException ex) {
		throw new AccountException(ex);
	}
	
	}
	

	
	

	public boolean check(String acunt_num, String pin) throws AccountException{
		//EntityManager entityManager=null;
		//boolean f = false;
		//for(Map.Entry<String,Employee> it: acuntMap.entrySet())
		//{
			//e=acuntMap.get(it.getKey());
		try{ //EntityManager entityManager=null;
			entityManager=JPAUtil.getEntityManager();
			e=entityManager.find(Employee.class, acunt_num);
			if(e!=null && e.getPin().equals(pin))
				return true;
			else
				return false;
		
	}catch(PersistenceException ex) {
		throw new AccountException(ex);
	}
		}
//ninad
	
	public boolean check(String acunt_num) throws AccountException{
		
		try{ //EntityManager entityManager=null;
			entityManager=JPAUtil.getEntityManager();
			e=entityManager.find(Employee.class, acunt_num);
			if(e!=null)
			 return true;
			else
				return false;					
		
	}catch(PersistenceException ex) {
		throw new AccountException(ex);
	}
		
	}
	

}